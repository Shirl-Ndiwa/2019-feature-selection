ps_project_plan <- drake_plan(
  ps_xgboost = target(
    makeParamSet(
      makeIntegerParam("nrounds", lower = 10, upper = 600),
      makeNumericParam("colsample_bytree", lower = 0.3, upper = 0.7),
      makeNumericParam("subsample", lower = 0.25, upper = 1),
      makeIntegerParam("max_depth", lower = 1, upper = 10),
      makeNumericParam("gamma", lower = 0, upper = 10),
      makeNumericParam("eta", lower = 0.001, upper = 0.6),
      makeNumericParam("min_child_weight", lower = 0, upper = 20)
    )
  )
)
